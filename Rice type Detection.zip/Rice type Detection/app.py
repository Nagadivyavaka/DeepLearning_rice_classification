from flask import Flask, render_template, request
from keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
import os

app = Flask(_name_)
model = load_model("rice.h5")

labels = ['Arborio', 'Basmati', 'Ipsala', 'Jasmine', 'Karacadag']

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/details')
def details():
    return render_template("details.html")

@app.route('/predict', methods=["POST"])
def predict():
    if 'file' not in request.files:
        return "No file part"
    
    file = request.files['file']
    if file.filename == '':
        return "No selected file"

    filepath = os.path.join("static", file.filename)
    file.save(filepath)

    img = image.load_img(filepath, target_size=(224, 224))
    img_tensor = image.img_to_array(img)
    img_tensor = np.expand_dims(img_tensor, axis=0)
    img_tensor /= 255.

    prediction = model.predict(img_tensor)
    predicted_class = labels[np.argmax(prediction)]

    return render_template("results.html", prediction=predicted_class, image_path=filepath)

if _name_ == "_main_":
    app.run(debug=True)